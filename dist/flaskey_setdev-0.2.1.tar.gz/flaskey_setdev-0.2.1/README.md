# 🚀 Flaskey SetDev

> Generate modern, ready-to-run Flask projects with a single command.

![PyPI](https://img.shields.io/pypi/v/flaskey-setdev)
![Python](https://img.shields.io/pypi/pyversions/flaskey-setdev)
![License](https://img.shields.io/pypi/l/flaskey-setdev)
![Downloads](https://img.shields.io/pypi/dm/flaskey-setdev)

---

## ✨ Features

- ⚡ One-command project scaffolding
- 🎨 Modern Bootstrap 5 UI out of the box
- 📦 Automatic virtual environment creation
- 🔧 Auto dependency installation via pip
- 🧱 Clean, beginner-friendly project structure
- 🖥️ Cross-platform — Windows, macOS, Linux
- 🔒 Auto-generated `.gitignore`

---

## 📦 Installation

```bash
pip install flaskey-setdev
```

---

## ⚡ Usage

```bash
flaskey flask <project-name>
```

**Example:**

```bash
flaskey flask myapp
```

**Other options:**

```bash
# Show help
flaskey --help

# Show version
flaskey --version
```

---

## 📁 Generated Project Structure

```
myapp/
├── app.py                  # Flask entry point
├── requirements.txt        # Project dependencies
├── .gitignore              # Ignores venv, __pycache__, etc.
├── templates/
│   └── index.html          # Bootstrap 5 landing page
├── static/
│   └── style.css           # Custom styles
└── venv/                   # Auto-created virtual environment
```

---

## 🚀 Run Your Project

**Windows:**
```bash
cd myapp
venv\Scripts\activate
python app.py
```

**macOS / Linux:**
```bash
cd myapp
source venv/bin/activate
python app.py
```

Then open your browser at:
```
http://127.0.0.1:5000
```

---

## 🎨 UI Preview

Your generated app comes with:

- Dark navbar with your project name
- Centered hero section — **"Build Something Amazing"**
- Primary + outline action buttons
- Responsive layout via Bootstrap 5
- Subtle gradient background

---

## 🛠️ Troubleshooting

### ❌ `flaskey` command not found

Add Python's scripts folder to your PATH:

```
C:\Users\<YourName>\AppData\Roaming\Python\Python3XX\Scripts
```

Restart your terminal after updating PATH.

---

### ❌ PowerShell execution policy error (Windows)

```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

### ❌ `pip` not found inside venv

Make sure you're using Python 3.7+ and that pip is available:

```bash
python --version
python -m ensurepip --upgrade
```

---

## 💡 Requirements

| Requirement | Version |
|-------------|---------|
| Python | 3.7+ |
| pip | Latest recommended |

---

## 🔥 Roadmap

- [ ] FastAPI project generator
- [ ] Django template support
- [ ] Interactive CLI mode (`--interactive`)
- [ ] Auto-open browser after project creation
- [ ] Multiple UI themes to choose from
- [ ] Docker support

---

## 👨‍💻 Author

**Samarth Patil**

---

## 🤝 Contributing

Contributions are welcome! Feel free to:

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Commit your changes (`git commit -m 'Add my feature'`)
4. Push to the branch (`git push origin feature/my-feature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## ⭐ Support

If Flaskey saved you time, give it a ⭐ on GitHub — it helps a lot!

---

## 🧠 Why Flaskey?

Stop wasting time on boilerplate. Flaskey gets you from zero to a running Flask app
in under 60 seconds — so you can focus on building, not configuring. 🚀